-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2021 at 06:04 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peminjaman_ruang`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `email_admin` varchar(250) NOT NULL,
  `nama_admin` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `divisi` varchar(200) NOT NULL,
  `jabatan_admin` varchar(200) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `email_admin`, `nama_admin`, `password`, `divisi`, `jabatan_admin`, `created_at`, `updated_at`) VALUES
(15, 'meliaharda@gmail.com', 'Melia Harda Saputra', 'JNE2021', 'IT Division', 'Karyawan', '2021-03-25 21:45:22', '2021-03-30 11:34:53');

-- --------------------------------------------------------

--
-- Table structure for table `pinjam_ruang`
--

CREATE TABLE `pinjam_ruang` (
  `id_pinjam` int(11) NOT NULL,
  `event_name` varchar(250) NOT NULL,
  `id_user` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `time` time NOT NULL,
  `end_time` time NOT NULL,
  `id_ruangan` int(11) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pinjam_ruang`
--

INSERT INTO `pinjam_ruang` (`id_pinjam`, `event_name`, `id_user`, `start_date`, `time`, `end_time`, `id_ruangan`, `keterangan`, `created_at`, `updated_at`) VALUES
(201, 'Meeting Jaringan', 22, '2021-04-16', '09:00:00', '10:00:00', 17, '#Be2525', '2021-04-15 09:27:56', '2021-04-15 09:27:56'),
(204, 'Meeting gudang', 22, '2021-04-30', '08:00:00', '08:30:00', 17, '#Be2525', '2021-04-15 09:29:58', '2021-04-15 09:34:15'),
(205, 'Meeting Jaringan', 22, '2021-04-17', '08:00:00', '09:00:00', 17, '#Be2525', '2021-04-15 09:31:15', '2021-04-15 09:31:15'),
(206, 'Meeting biasa', 22, '2021-04-17', '08:00:00', '09:00:00', 21, '#Be2525', '2021-04-15 09:31:59', '2021-04-15 09:31:59');

-- --------------------------------------------------------

--
-- Table structure for table `ruangan`
--

CREATE TABLE `ruangan` (
  `id_ruangan` int(11) NOT NULL,
  `nama_ruangan` varchar(250) NOT NULL,
  `gedung` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ruangan`
--

INSERT INTO `ruangan` (`id_ruangan`, `nama_ruangan`, `gedung`, `status`, `created_at`, `updated_at`) VALUES
(17, 'Meeting J', 'Tomang 11', '', 2021, 2021),
(21, 'Meeting N', 'Tomang 11', '', 2021, 2021),
(22, 'Meeting E', 'Tomang 11', '', 2021, 2021),
(23, 'Meeting C', 'Tomang 6', '', 2021, 2021);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `nama_user` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `divisi` varchar(200) NOT NULL,
  `jabatan_user` varchar(200) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `nama_user`, `password`, `divisi`, `jabatan_user`, `created_at`, `updated_at`) VALUES
(22, 'harda@gmail.com', 'Melia Harda', 'JNE2021', 'Accounting', 'Magang', '2021-03-29 16:35:37', '2021-03-31 16:10:40'),
(35, 'melia@gmail.com', 'Saputra', 'JNE2021', 'Accounting', 'Karyawan', '2021-04-06 15:51:20', '2021-04-06 15:51:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `nama_admin` (`email_admin`);

--
-- Indexes for table `pinjam_ruang`
--
ALTER TABLE `pinjam_ruang`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id_ruangan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `nama_user` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `pinjam_ruang`
--
ALTER TABLE `pinjam_ruang`
  MODIFY `id_pinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;

--
-- AUTO_INCREMENT for table `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `id_ruangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
